<?php

namespace App\Http\Controllers;

use App\Models\Books;
use App\Models\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use PayPalCheckoutSdk\Core\PayPalHttpClient;
use PayPalCheckoutSdk\Core\SandboxEnvironment;
use PayPalCheckoutSdk\Core\ProductionEnvironment;
use PayPalCheckoutSdk\Orders\OrdersCreateRequest;
use PayPalCheckoutSdk\Orders\OrdersCaptureRequest;

class PaymentController extends Controller
{
    private $client;

    public function __construct()
    {
        $this->client = $this->getPayPalClient();
    }

    private function getPayPalClient()
    {
        $clientId = config('services.paypal.client_id');
        $clientSecret = config('services.paypal.client_secret');
        $mode = config('services.paypal.mode', 'sandbox');

        if ($mode === 'live') {
            $environment = new ProductionEnvironment($clientId, $clientSecret);
        } else {
            $environment = new SandboxEnvironment($clientId, $clientSecret);
        }

        return new PayPalHttpClient($environment);
    }

    public function createSession(Request $request)
    {
        $request->validate([
            'book_id' => 'required|exists:books,id',
        ]);

        // Check if PayPal keys are configured
        if (!config('services.paypal.client_id') || !config('services.paypal.client_secret')) {
            return redirect()->back()->with('error', 'Payment system is not configured. Please contact administrator.');
        }

        $book = Books::findOrFail($request->book_id);

        // Check if book is available/vente and has a price
        if (!in_array($book->status, ['available', 'vente']) || !$book->price) {
            return redirect()->back()->with('error', 'Book is not available for borrowing/purchase.');
        }

        // Check if user already has a pending transaction for this book
        $existingTransaction = Transaction::where('user_id', Auth::id())
                                          ->where('book_id', $book->id)
                                          ->whereIn('status', ['pending', 'completed'])
                                          ->first();
        if ($existingTransaction) {
            return redirect()->back()->with('error', 'You already have a transaction for this book.');
        }

        try {
            // Create transaction record
            $transaction = Transaction::create([
                'user_id' => Auth::id(),
                'book_id' => $book->id,
                'type' => $book->status === 'vente' ? 'purchase' : 'borrow',
                'status' => 'pending',
                'amount' => $book->price,
                'payment_status' => 'pending',
            ]);

            // Create PayPal Order
            $request = new OrdersCreateRequest();
            $request->prefer('return=representation');
            $request->body = [
                "intent" => "CAPTURE",
                "purchase_units" => [[
                    "reference_id" => $transaction->id,
                    "amount" => [
                        "value" => number_format($book->price, 2),
                        "currency_code" => "USD"
                    ],
                    "description" => ($book->status === 'vente' ? 'Purchase: ' : 'Borrow: ') . $book->title . ' by ' . $book->author,
                ]],
                "application_context" => [
                    "cancel_url" => route('payment.cancel', ['transaction_id' => $transaction->id]),
                    "return_url" => route('payment.success', ['order_id' => '{order_id}']),
                ]
            ];

            $response = $this->client->execute($request);
            $order = $response->result;

            // Update transaction with order id
            $transaction->update([
                'payment_id' => $order->id,
                'payment_method' => 'paypal',
            ]);

            // Find approval URL
            $approvalUrl = null;
            foreach ($order->links as $link) {
                if ($link->rel === 'approve') {
                    $approvalUrl = $link->href;
                    break;
                }
            }

            if (!$approvalUrl) {
                throw new \Exception('PayPal approval URL not found');
            }

            return redirect($approvalUrl);
        } catch (\Exception $e) {
            // Delete the transaction if PayPal order creation failed
            if (isset($transaction)) {
                $transaction->delete();
            }
            return redirect()->back()->with('error', 'Failed to initiate payment. Please try again.');
        }
    }

    public function success(Request $request)
    {
        $orderId = $request->get('order_id');

        if (!$orderId) {
            return redirect('/')->with('error', 'Invalid payment order.');
        }

        try {
            // Capture the PayPal order
            $captureRequest = new OrdersCaptureRequest($orderId);
            $response = $this->client->execute($captureRequest);
            $order = $response->result;

            // Find transaction by payment_id
            $transaction = Transaction::where('payment_id', $orderId)->firstOrFail();

            if ($transaction->user_id !== Auth::id()) {
                return redirect('/')->with('error', 'Unauthorized access.');
            }

            // Check if payment was successful
            if ($order->status === 'COMPLETED') {
                // Update transaction and book status
                $transaction->update([
                    'payment_status' => 'paid',
                    'status' => 'completed',
                ]);

                $book = $transaction->book;
                if ($transaction->type === 'borrow') {
                    $book->update(['status' => 'borrowed']);
                } elseif ($transaction->type === 'purchase') {
                    // For purchase, book remains 'vente' or could be marked as sold
                    // You might want to add a 'sold' status or handle differently
                }

                return view('payment.success', compact('transaction'));
            } else {
                // Payment not completed
                $transaction->update(['payment_status' => 'failed']);
                return redirect('/')->with('error', 'Payment was not completed.');
            }
        } catch (\Exception $e) {
            return redirect('/')->with('error', 'Payment verification failed.');
        }
    }

    public function cancel(Request $request)
    {
        $transactionId = $request->get('transaction_id');

        if ($transactionId) {
            $transaction = Transaction::find($transactionId);
            if ($transaction && $transaction->user_id === Auth::id()) {
                $transaction->update(['payment_status' => 'cancelled']);
            }
        }

        return view('payment.cancel');
    }
}
