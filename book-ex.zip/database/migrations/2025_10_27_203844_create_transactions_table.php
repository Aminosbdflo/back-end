<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('transactions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->onDelete('cascade');
            $table->foreignId('book_id')->constrained('books')->onDelete('cascade');
            $table->enum('type', ['borrow']);
            $table->enum('status', ['pending', 'completed', 'rejected'])->default('pending');
            $table->decimal('amount', 8, 2)->nullable(); // للدفع إذا كان purchase
            $table->foreignId('approved_by')->nullable()->constrained('users')->onDelete('set null'); // Admin اللي قبل
            $table->text('notes')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('transactions');
    }
};
