
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Books')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12 bg-gray-50 min-h-screen">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="p-8">
                    <?php if(session('success')): ?>
                        <div class="mb-6 p-4 bg-green-50 border-l-4 border-green-500 text-green-800 rounded-r-lg flex items-start">
                            <svg class="w-6 h-6 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                            </svg>
                            <span><?php echo e(session('success')); ?></span>
                        </div>
                    <?php endif; ?>

                    <div class="flex justify-between items-center mb-6">
                        <div>
                            <h3 class="text-2xl font-bold text-gray-800"><?php echo e(__("My Book Collection")); ?></h3>
                            <p class="text-gray-600 text-sm mt-1">Manage and organize your personal library</p>
                        </div>

                        <button id="openModalBtn" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg shadow-md transition duration-300 ease-in-out transform hover:scale-105 flex items-center">
                            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/>
                            </svg>
                            Add New Book
                        </button>
                    </div>

                    <!-- Search Form -->
                    <div class="mb-6">
                        <form method="GET" action="<?php echo e(route('user.books')); ?>" class="flex items-center space-x-4">
                            <div class="flex-1">
                                <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Search by title, author, or genre..." class="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                            </div>
                            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg shadow-md transition duration-300 ease-in-out transform hover:scale-105 flex items-center">
                                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                                </svg>
                                Search
                            </button>
                            <?php if(request('search')): ?>
                                <a href="<?php echo e(route('user.books')); ?>" class="bg-gray-600 hover:bg-gray-700 text-white font-semibold py-3 px-6 rounded-lg shadow-md transition duration-300 ease-in-out transform hover:scale-105 flex items-center">
                                    <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                                    </svg>
                                    Clear
                                </a>
                            <?php endif; ?>
                        </form>
                    </div>

                    <!-- Books Table -->
                    <div class="overflow-hidden border border-gray-200 rounded-lg shadow-sm">
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gradient-to-r from-gray-50 to-gray-100">
                                    <tr>
                                        <th class="py-4 px-6 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Image</th>
                                        <th class="py-4 px-6 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Title</th>
                                        <th class="py-4 px-6 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Author</th>
                                        <th class="py-4 px-6 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Published Year</th>
                                        <th class="py-4 px-6 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Genre</th>
                                        <th class="py-4 px-6 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Summary</th>
                                        <th class="py-4 px-6 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Category</th>
                                        <th class="py-4 px-6 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Book Type</th>
                                        <th class="py-4 px-6 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Price</th>
                                        <th class="py-4 px-6 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Status</th>
                                        <th class="py-4 px-6 text-center text-xs font-semibold text-gray-700 uppercase tracking-wider">Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr class="hover:bg-gray-50 transition duration-150">
                                            <td class="py-4 px-6 text-sm text-center">
                                                <?php if($book->image): ?>
                                                    <img src="<?php echo e(asset('storage/' . $book->image)); ?>" alt="Book Image" class="w-12 h-12 object-cover rounded-lg mx-auto">
                                                <?php else: ?>
                                                    <div class="w-12 h-12 bg-gray-200 rounded-lg flex items-center justify-center mx-auto">
                                                        <svg class="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
                                                        </svg>
                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                            <td class="py-4 px-6 text-sm font-medium text-gray-900"><?php echo e($book->title); ?></td>
                                            <td class="py-4 px-6 text-sm text-gray-700"><?php echo e($book->author); ?></td>
                                            <td class="py-4 px-6 text-sm text-gray-700"><?php echo e($book->published_year); ?></td>
                                            <td class="py-4 px-6 text-sm text-gray-700">
                                                <span class="inline-flex px-3 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">
                                                    <?php echo e($book->genre); ?>

                                                </span>
                                            </td>
                                            <td class="py-4 px-6 text-sm text-gray-600 max-w-xs truncate"><?php echo e($book->summary); ?></td>
                                            <td class="py-4 px-6 text-sm text-gray-700">
                                                <span class="inline-flex px-3 py-1 text-xs font-medium rounded-full bg-purple-100 text-purple-800">
                                                    <?php echo e($book->category->name ?? 'N/A'); ?>

                                                </span>
                                            </td>
                                            <td class="py-4 px-6 text-sm text-gray-700">
                                                <span class="inline-flex px-3 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800">
                                                    <?php echo e($book->bookType->name ?? 'N/A'); ?>

                                                </span>
                                            </td>
                                            <td class="py-4 px-6 text-sm text-gray-700">
                                                <?php if(optional($book->bookType)->name === 'vente' && $book->price): ?>
                                                    $<?php echo e(number_format($book->price, 2)); ?>

                                                <?php else: ?>
                                                    N/A
                                                <?php endif; ?>
                                            </td>

                                            <td class="py-4 px-6 text-sm text-gray-700">
                                                <span class="inline-flex px-3 py-1 text-xs font-medium rounded-full <?php if($book->status == 'available'): ?> bg-green-100 text-green-800 <?php else: ?> bg-red-100 text-red-800 <?php endif; ?>">
                                                    <?php echo e(ucfirst($book->status)); ?>

                                                </span>
                                            </td>

                                            <td class="py-4 px-6 text-sm text-center">
                                                <div class="flex justify-center space-x-3 items-center">
                                                    
                                                    <?php if($book->status === 'available'): ?>
                                                        <form action="<?php echo e(route('user.books.request', $book->id)); ?>" method="POST" class="inline">
                                                            <?php echo csrf_field(); ?>
                                                            <button type="submit" class="flex items-center px-3 py-2 rounded-md bg-purple-50 hover:bg-purple-100 text-purple-700 text-sm" title="Request Book">
                                                                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                                                                </svg>
                                                                Request
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>

                                                    
                                                    <button
                                                        type="button"
                                                        class="flex items-center px-3 py-2 rounded-md bg-yellow-50 hover:bg-yellow-100 text-yellow-700 text-sm"
                                                        data-book='<?php echo json_encode($book->loadMissing(["category", "bookType"]), 512) ?>'
                                                        onclick="openEditModal(this)"
                                                        aria-label="Edit book">
                                                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                                                        </svg>

                                                    </button>

                                                    
                                                    <form action="<?php echo e(route('user.books.destroy', $book->id)); ?>" method="POST" class="inline">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="text-red-600 hover:text-red-800 transition duration-150" onclick="return confirm('Are you sure you want to delete this book?')">
                                                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                                                            </svg>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="11" class="py-12 px-6 text-center">
                                                <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
                                                </svg>
                                                <p class="mt-4 text-gray-500 text-lg font-medium">No books found</p>
                                                <p class="mt-2 text-gray-400 text-sm">Start building your library by adding your first book</p>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- Pagination -->
                        <div class="mt-6 px-6 py-4">
                            <?php echo e($books->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div id="editBookModal" class="fixed inset-0 bg-black bg-opacity-50 overflow-y-auto h-full w-full hidden z-50 backdrop-blur-sm">
            <div class="relative top-10 mx-auto p-0 border-0 w-full max-w-2xl">
                <div class="bg-white shadow-2xl rounded-2xl overflow-hidden">
                    <div class="bg-gradient-to-r from-green-600 to-green-700 px-8 py-6">
                        <div class="flex justify-between items-center">
                            <h3 class="text-2xl font-bold text-white flex items-center">
                                <svg class="w-7 h-7 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                                </svg>
                                Edit Book
                            </h3>
                            <button type="button" id="closeEditModalBtn" class="text-white hover:text-gray-200 transition duration-150">
                                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                                </svg>
                            </button>
                        </div>
                    </div>

                    <form action="" method="POST" id="editBookForm" enctype="multipart/form-data" class="p-8">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div class="md:col-span-2">
                                <label for="edit_title" class="block text-sm font-semibold text-gray-700 mb-2">Title</label>
                                <input type="text" name="title" id="edit_title" class="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500" placeholder="Enter book title" required>
                            </div>

                            <div>
                                <label for="edit_author" class="block text-sm font-semibold text-gray-700 mb-2">Author</label>
                                <input type="text" name="author" id="edit_author" class="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500" placeholder="Author name" required>
                            </div>

                            <div>
                                <label for="edit_published_year" class="block text-sm font-semibold text-gray-700 mb-2">Published Year</label>
                                <input type="number" name="published_year" id="edit_published_year" class="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500" placeholder="2024" required>
                            </div>

                            <div>
                                <label for="edit_genre" class="block text-sm font-semibold text-gray-700 mb-2">Genre</label>
                                <input type="text" name="genre" id="edit_genre" class="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500" placeholder="e.g., Fiction, Mystery" required>
                            </div>

                            <div>
                                <label for="edit_category_id" class="block text-sm font-semibold text-gray-700 mb-2">Category</label>
                                <select name="category_id" id="edit_category_id" class="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500" required>
                                    <option value="">Select Category</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div>
                                <label for="edit_book_type_id" class="block text-sm font-semibold text-gray-700 mb-2">Book Type</label>
                                <select name="book_type_id" id="edit_book_type_id" class="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500" required>
                                    <option value="">Select Book Type</option>
                                    <?php $__currentLoopData = $bookTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($bookType->id); ?>" data-name="<?php echo e($bookType->name); ?>"><?php echo e($bookType->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div>
                                <label for="edit_status" class="block text-sm font-semibold text-gray-700 mb-2">Status</label>
                                <select name="status" id="edit_status" class="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500" required>
                                    <option value="">Select Status</option>
                                    <option value="available">Available</option>
                                    <option value="borrowed">Borrowed</option>
                                </select>
                            </div>

                            <div id="editPriceField" style="display: none;">
                                <label for="edit_price" class="block text-sm font-semibold text-gray-700 mb-2">Price ($)</label>
                                <input type="number" name="price" id="edit_price" step="0.01" min="0" class="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500" placeholder="0.00">
                            </div>

                            <div class="md:col-span-2">
                                <label for="edit_summary" class="block text-sm font-semibold text-gray-700 mb-2">Summary</label>
                                <textarea name="summary" id="edit_summary" rows="4" class="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 resize-none" placeholder="Brief description of the book..."></textarea>
                            </div>

                            <div class="md:col-span-2">
                                <label for="edit_image" class="block text-sm font-semibold text-gray-700 mb-2">Book Image</label>
                                <input type="file" name="image" id="edit_image" accept="image/*" class="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500">
                            </div>
                        </div>

                        <div class="flex justify-end space-x-3 mt-8 pt-6 border-t border-gray-200">
                            <button type="button" id="closeEditModalBtn2" class="px-6 py-3 bg-gray-100 text-gray-700 font-semibold rounded-lg hover:bg-gray-200">
                                Cancel
                            </button>
                            <button type="submit" class="px-6 py-3 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 shadow-md transform hover:scale-105 flex items-center">
                                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                                </svg>
                                Update Book
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        
        <div id="createBookModal" class="fixed inset-0 bg-black bg-opacity-50 overflow-y-auto h-full w-full hidden z-50 backdrop-blur-sm">
            <div class="relative top-10 mx-auto p-0 border-0 w-full max-w-2xl">
                <div class="bg-white shadow-2xl rounded-2xl overflow-hidden">
                    <div class="bg-gradient-to-r from-blue-600 to-blue-700 px-8 py-6">
                        <div class="flex justify-between items-center">
                            <h3 class="text-2xl font-bold text-white flex items-center">
                                <svg class="w-7 h-7 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
                                </svg>
                                Add New Book
                            </h3>
                            <button type="button" id="closeModalBtn" class="text-white hover:text-gray-200 transition duration-150">
                                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                                </svg>
                            </button>
                        </div>
                    </div>

                    <form action="<?php echo e(route('user.books.store')); ?>" method="POST" id="createBookForm" enctype="multipart/form-data" class="p-8">
                        <?php echo csrf_field(); ?>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div class="md:col-span-2">
                                <label for="title" class="block text-sm font-semibold text-gray-700 mb-2">Title</label>
                                <input type="text" name="title" id="title" class="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Enter book title" required>
                            </div>

                            <div>
                                <label for="author" class="block text-sm font-semibold text-gray-700 mb-2">Author</label>
                                <input type="text" name="author" id="author" class="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Author name" required>
                            </div>

                            <div>
                                <label for="published_year" class="block text-sm font-semibold text-gray-700 mb-2">Published Year</label>
                                <input type="number" name="published_year" id="published_year" class="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="2024" required>
                            </div>

                            <div>
                                <label for="genre" class="block text-sm font-semibold text-gray-700 mb-2">Genre</label>
                                <input type="text" name="genre" id="genre" class="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="e.g., Fiction, Mystery" required>
                            </div>

                            <div>
                                <label for="category_id" class="block text-sm font-semibold text-gray-700 mb-2">Category</label>
                                <select name="category_id" id="category_id" class="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                                    <option value="">Select Category</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>" data-name="<?php echo e($category->name); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div>
                                <label for="book_type_id" class="block text-sm font-semibold text-gray-700 mb-2">Book Type</label>
                                <select name="book_type_id" id="book_type_id" class="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                                    <option value="">Select Book Type</option>
                                    <?php $__currentLoopData = $bookTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($bookType->id); ?>" data-name="<?php echo e($bookType->name); ?>"><?php echo e($bookType->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div>
                                <label for="status" class="block text-sm font-semibold text-gray-700 mb-2">Status</label>
                                <select name="status" id="status" class="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                                    <option value="">Select Status</option>
                                    <option value="available">Available</option>
                                    <option value="borrowed">Borrowed</option>
                                </select>
                            </div>

                            <div id="priceField" style="display: none;">
                                <label for="price" class="block text-sm font-semibold text-gray-700 mb-2">Price ($)</label>
                                <input type="number" name="price" id="price" step="0.01" min="0" class="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="0.00">
                            </div>

                            <div class="md:col-span-2">
                                <label for="summary" class="block text-sm font-semibold text-gray-700 mb-2">Summary</label>
                                <textarea name="summary" id="summary" rows="4" class="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none" placeholder="Brief description of the book..."></textarea>
                            </div>

                            <div class="md:col-span-2">
                                <label for="image" class="block text-sm font-semibold text-gray-700 mb-2">Book Image</label>
                                <input type="file" name="image" id="image" accept="image/*" class="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                            </div>
                        </div>

                        <div class="flex justify-end space-x-3 mt-8 pt-6 border-t border-gray-200">
                            <button type="button" id="closeModalBtn2" class="px-6 py-3 bg-gray-100 text-gray-700 font-semibold rounded-lg hover:bg-gray-200">Cancel</button>
                            <button type="submit" class="px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 shadow-md transform hover:scale-105 flex items-center">
                                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                                </svg>
                                Create Book
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    
    <script>
        // Modal elements
        const createModal = document.getElementById('createBookModal');
        const openModalBtn = document.getElementById('openModalBtn');
        const closeModalBtn = document.getElementById('closeModalBtn');
        const closeModalBtn2 = document.getElementById('closeModalBtn2');
        const createBookForm = document.getElementById('createBookForm');

        const editModal = document.getElementById('editBookModal');
        const closeEditModalBtn = document.getElementById('closeEditModalBtn');
        const closeEditModalBtn2 = document.getElementById('closeEditModalBtn2');
        const editBookForm = document.getElementById('editBookForm');

        // Open / close create modal
        openModalBtn.addEventListener('click', () => createModal.classList.remove('hidden'));
        closeModalBtn.addEventListener('click', () => createModal.classList.add('hidden'));
        closeModalBtn2.addEventListener('click', () => createModal.classList.add('hidden'));

        // Close create modal after submit (lets server handle redirect/flash)
        createBookForm.addEventListener('submit', () => {
            // small delay to make user see the click, then hide; server will redirect on success
            setTimeout(() => createModal.classList.add('hidden'), 100);
        });

        // Helper: toggle price field by bookType data-name attribute
        function togglePriceField(selectElement, priceFieldId, priceInputId) {
            const selectedOption = selectElement.options[selectElement.selectedIndex];
            const bookTypeName = selectedOption ? selectedOption.getAttribute('data-name') : '';
            const priceField = document.getElementById(priceFieldId);
            const priceInput = document.getElementById(priceInputId);

            if (bookTypeName === 'vente') {
                priceField.style.display = 'block';
                priceInput.required = true;
            } else {
                priceField.style.display = 'none';
                priceInput.required = false;
                if (priceInput) priceInput.value = '';
            }
        }

        // Wire up create modal book type toggle
        document.getElementById('book_type_id').addEventListener('change', function() {
            togglePriceField(this, 'priceField', 'price');
        });

        // Wire up edit modal book type toggle
        document.getElementById('edit_book_type_id').addEventListener('change', function() {
            togglePriceField(this, 'editPriceField', 'edit_price');
        });

        // Initialize create modal price field on DOMContentLoaded
        document.addEventListener('DOMContentLoaded', function() {
            togglePriceField(document.getElementById('book_type_id'), 'priceField', 'price');
        });

        // edit modal close handlers
        closeEditModalBtn.addEventListener('click', () => editModal.classList.add('hidden'));
        closeEditModalBtn2.addEventListener('click', () => editModal.classList.add('hidden'));

        // global click to close modals when clicking on backdrop
        window.addEventListener('click', (e) => {
            if (e.target === createModal) createModal.classList.add('hidden');
            if (e.target === editModal) editModal.classList.add('hidden');
        });

        // Open edit modal using the button that holds data-book JSON
        function openEditModal(button) {
            try {
                const book = JSON.parse(button.getAttribute('data-book'));
                // Show the modal first
                document.getElementById('editBookModal').classList.remove('hidden');
                
                // populate fields
                document.getElementById('edit_title').value = book.title ?? '';
                document.getElementById('edit_author').value = book.author ?? '';
                document.getElementById('edit_published_year').value = book.published_year ?? '';
                document.getElementById('edit_genre').value = book.genre ?? '';
                document.getElementById('edit_summary').value = book.summary ?? '';
                document.getElementById('edit_category_id').value = book.category_id ?? '';
                document.getElementById('edit_book_type_id').value = book.book_type_id ?? '';
                document.getElementById('edit_status').value = book.status ?? '';
                const editPriceInput = document.getElementById('edit_price');
                if (book.price) editPriceInput.value = book.price;

                // set form action: use a base url + id (adjust base URL if your route is different)
                // base url generated by Blade to avoid hardcoding domain
                editBookForm.action = `<?php echo e(route('user.books')); ?>/${book.id}`;

                // toggle price field visibility for edit modal
                togglePriceField(document.getElementById('edit_book_type_id'), 'editPriceField', 'edit_price');

                // show modal
                editModal.classList.remove('hidden');

            } catch (err) {
                console.error('Failed to open edit modal:', err);
                alert('Could not open edit modal. See console for details.');
            }
        }

        // Close edit modal after submit
        editBookForm.addEventListener('submit', () => {
            setTimeout(() => editModal.classList.add('hidden'), 100);
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\book-ex\resources\views/books.blade.php ENDPATH**/ ?>