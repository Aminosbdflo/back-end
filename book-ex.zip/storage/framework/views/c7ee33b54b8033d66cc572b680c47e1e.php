<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-900 leading-tight">
            <?php echo e(__('My Conversations')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="flex flex-col lg:flex-row h-[calc(100vh-12rem)] bg-gray-50 rounded-lg shadow-sm overflow-hidden">
                <!-- Left Sidebar: Conversations List -->
                <div class="w-full lg:w-96 bg-white border-b lg:border-b-0 lg:border-r border-gray-200 flex flex-col">
                    <div class="p-4 border-b border-gray-200 flex-shrink-0">
                        <h3 class="text-lg font-semibold text-gray-900">Chats</h3>
                    </div>
                    <div class="flex-1 overflow-y-auto p-4 space-y-1">
                        <?php if($conversations->count() > 0): ?>
                            <?php $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div data-partner-id="<?php echo e($conversation['partner']->id); ?>" class="conversation-item cursor-pointer p-3 rounded-lg border border-transparent hover:bg-gray-50 hover:border-gray-300 transition-colors block">
                                    <div class="flex items-center justify-between">
                                        <div class="flex items-center space-x-3 flex-1 min-w-0">
                                            <div class="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white font-semibold text-sm flex-shrink-0">
                                                <?php echo e(strtoupper(substr($conversation['partner']->name, 0, 1))); ?>

                                            </div>
                                            <div class="min-w-0 flex-1">
                                                <h4 class="font-semibold text-gray-900 truncate"><?php echo e($conversation['partner']->name); ?></h4>
                                                <p class="text-sm text-gray-600 latest-message-text truncate">
                                                    <?php if($conversation['latest_message']): ?>
                                                        <?php echo e(Str::limit($conversation['latest_message']->message, 30)); ?>

                                                    <?php else: ?>
                                                        No messages yet
                                                    <?php endif; ?>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="text-right flex-shrink-0 ml-2">
                                            <p class="text-xs text-gray-500 latest-message-time"><?php echo e($conversation['latest_message'] ? $conversation['latest_message']->created_at->diffForHumans() : ''); ?></p>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="text-center py-12">
                                <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
                                </svg>
                                <h3 class="mt-2 text-sm font-medium text-gray-900">No conversations</h3>
                                <p class="mt-1 text-sm text-gray-500">You haven't started any conversations yet. Start chatting by requesting a book from another user.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Right Panel: Chat Area -->
                <div class="flex-1 flex flex-col">
                    <!-- Chat Header -->
                    <div id="chatHeader" class="hidden p-4 border-b border-gray-200 bg-gradient-to-r from-blue-50 to-indigo-50">
                        <div class="flex items-center space-x-3">
                            <div id="chatAvatar" class="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white font-semibold text-sm">
                            </div>
                            <div>
                                <h2 id="chatPartnerName" class="font-semibold text-gray-900 text-lg"></h2>
                                <p class="text-sm text-gray-500">Active now</p>
                            </div>
                        </div>
                    </div>

                    <!-- No Chat Selected -->
                    <div id="noChatSelected" class="flex-1 flex items-center justify-center bg-gray-50 p-6">
                        <div class="text-center">
                            <svg class="mx-auto h-16 w-16 text-gray-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
                            </svg>
                            <h3 class="mt-2 text-xl font-medium text-gray-900">Select a chat</h3>
                            <p class="mt-2 text-gray-500">Pick a conversation to start messaging</p>
                        </div>
                    </div>

                    <!-- Chat Messages -->
                    <div id="chatContainer" class="hidden flex flex-col flex-1 bg-white">
                        <div id="messages" class="flex-1 overflow-y-auto p-6 space-y-4 bg-gray-50">
                            <!-- Messages will be loaded here -->
                        </div>
                        <!-- Message Input -->
                        <div class="p-6 bg-white border-t border-gray-200">
                            <form id="messageForm" class="flex space-x-4">
                                <input type="text" id="messageInput" placeholder="Type your message..." class="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none" disabled>
                                <button type="submit" class="px-6 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-semibold rounded-lg shadow-lg hover:shadow-xl disabled:opacity-50" disabled>Send</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php
        $pusherKey = config('broadcasting.connections.pusher.key');
        $pusherCluster = config('broadcasting.connections.pusher.options.cluster');
    ?>

    <script src="https://js.pusher.com/8.2.0/pusher.min.js"></script>
    <script>
        const currentUserId = <?php echo e(Auth::id()); ?>;
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        let selectedPartnerId = null;

        // Initialize Pusher
        const pusher = new Pusher('<?php echo e($pusherKey); ?>', {
            cluster: '<?php echo e($pusherCluster); ?>',
            encrypted: true,
            auth: {
                headers: {
                    'X-CSRF-Token': csrfToken,
                },
            },
        });

        // Subscribe to user's private channel
        const channel = pusher.subscribe('private-chat.' + currentUserId);

        channel.bind('App\\Events\\MessageSent', function(data) {
            const message = data.message;
            const partnerId = (message.sender_id === currentUserId) ? message.receiver_id : message.sender_id;

            // Update conversation list
            const conversationItem = document.querySelector(`[data-partner-id="${partnerId}"]`);
            if (conversationItem) {
                const messageTextEl = conversationItem.querySelector('.latest-message-text');
                const limitedMessage = message.message.length > 30 ? message.message.substring(0, 30) + '...' : message.message;
                messageTextEl.textContent = limitedMessage;

                // Update timestamp
                const timeEl = conversationItem.querySelector('.latest-message-time');
                const now = new Date();
                const messageTime = new Date(message.created_at);
                const diffInSeconds = Math.floor((now - messageTime) / 1000);
                let timeText;
                if (diffInSeconds < 60) {
                    timeText = 'Just now';
                } else if (diffInSeconds < 3600) {
                    timeText = Math.floor(diffInSeconds / 60) + ' min ago';
                } else if (diffInSeconds < 86400) {
                    timeText = Math.floor(diffInSeconds / 3600) + ' hours ago';
                } else {
                    timeText = Math.floor(diffInSeconds / 86400) + ' days ago';
                }
                timeEl.textContent = timeText;

                // Move conversation to top
                const container = conversationItem.parentNode;
                container.insertBefore(conversationItem, container.firstChild);
            } else {
                // New conversation - reload to show it
                location.reload();
            }

            // Update selected chat if relevant
            if (selectedPartnerId === partnerId) {
                if (message.sender_id !== currentUserId) {
                    appendMessage(message);
                }
            }
        });

        // Chat functions
        function appendMessage(message) {
            const messagesContainer = document.getElementById('messages');
            if (!messagesContainer) return;
            const messageDiv = document.createElement('div');
            messageDiv.className = `flex ${message.sender_id === currentUserId ? 'justify-end' : 'justify-start'} mb-4`;
            const time = new Date(message.created_at).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
            const bubbleClass = message.sender_id === currentUserId ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white' : 'bg-white text-gray-800 border border-gray-200 shadow-sm';
            messageDiv.innerHTML = `
                <div class="max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${bubbleClass}">
                    <p class="text-sm">${message.message}</p>
                    <p class="text-xs mt-1 opacity-75">${time}</p>
                </div>
            `;
            messagesContainer.appendChild(messageDiv);
            scrollToBottom();
        }

        function scrollToBottom() {
            const messagesContainer = document.getElementById('messages');
            if (messagesContainer) {
                messagesContainer.scrollTop = messagesContainer.scrollHeight;
            }
        }

        function loadMessages(partnerId) {
            const messagesContainer = document.getElementById('messages');
            if (!messagesContainer) return;
            messagesContainer.innerHTML = '';
            fetch(`/chat/${partnerId}/messages`, {
                headers: {
                    'X-CSRF-TOKEN': csrfToken
                }
            })
            .then(response => response.json())
            .then(messages => {
                messages.forEach(appendMessage);
            })
            .catch(error => {
                console.error('Error loading messages:', error);
                messagesContainer.innerHTML = 'Error loading messages';
            });
        }

        function updateChatHeader(name) {
            document.getElementById('chatPartnerName').textContent = name;
            const avatar = document.getElementById('chatAvatar');
            avatar.textContent = name.charAt(0).toUpperCase();
        }

        function selectConversation(partnerId) {
            selectedPartnerId = partnerId;
            // Update UI selection
            document.querySelectorAll('.conversation-item').forEach(item => {
                item.classList.remove('bg-blue-50', 'border-blue-200');
            });
            const selectedItem = document.querySelector(`[data-partner-id="${partnerId}"]`);
            if (selectedItem) {
                selectedItem.classList.add('bg-blue-50', 'border-blue-200');
                const nameEl = selectedItem.querySelector('h4');
                if (nameEl) {
                    updateChatHeader(nameEl.textContent);
                }
            }
            // Show chat panels
            document.getElementById('noChatSelected').classList.add('hidden');
            document.getElementById('chatHeader').classList.remove('hidden');
            document.getElementById('chatContainer').classList.remove('hidden');
            // Enable form
            const input = document.getElementById('messageInput');
            const button = document.querySelector('#messageForm button');
            input.disabled = false;
            button.disabled = false;
            // Load messages
            loadMessages(partnerId);
        }

        // Event Listeners
        document.addEventListener('DOMContentLoaded', function() {
            // Conversation item clicks
            const conversationItems = document.querySelectorAll('.conversation-item');
            conversationItems.forEach(function(item) {
                item.addEventListener('click', function() {
                    selectConversation(this.dataset.partnerId);
                });
            });
            // Message form submit
            const messageForm = document.getElementById('messageForm');
            if (messageForm) {
                messageForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    if (!selectedPartnerId) {
                        return;
                    }
                    const messageInput = document.getElementById('messageInput');
                    const message = messageInput.value.trim();
                    if (!message) return;
                    fetch(`/chat/${selectedPartnerId}/send`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': csrfToken
                        },
                        body: JSON.stringify({ message: message })
                    })
                    .then(response => response.json())
                    .then(data => {
                        appendMessage(data);
                        messageInput.value = '';
                    })
                    .catch(error => {
                        console.error('Error sending message:', error);
                    });
                });
            }
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\book-ex\resources\views/conversations.blade.php ENDPATH**/ ?>